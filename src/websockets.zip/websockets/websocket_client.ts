// import WebSocket from 'ws';

// // Connect to the WebSocket server running on Express
// const ws = new WebSocket('ws://localhost:4321');

// // Handle connection open
// ws.on('open', () => {
//     console.log('Connected to the server');
//     ws.send('Hello, Server!');
// });

// // Handle messages from the server
// ws.on('message', (data: string) => {
//     console.log('Message from server:', data);
// });

// // Handle connection close
// ws.on('close', () => {
//     console.log('Connection closed by server');
// });

// // Handle errors
// ws.on('error', (error) => {
//     console.error('WebSocket error:', error);
// });
